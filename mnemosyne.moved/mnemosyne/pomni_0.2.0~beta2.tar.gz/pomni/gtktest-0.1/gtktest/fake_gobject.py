"""Proxy for the GTK gobject module."""

from real_gobject import *
