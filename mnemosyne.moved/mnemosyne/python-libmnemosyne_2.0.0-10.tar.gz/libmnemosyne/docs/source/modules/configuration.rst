:mod:`Configuration`
===============================

.. automodule:: mnemosyne.libmnemosyne.configuration
   
.. autoclass:: Configuration
   :members:
   :undoc-members:   
   :inherited-members:
