:mod:`CardTypeConverter`
======================

.. automodule:: mnemosyne.libmnemosyne.card_type_converter

.. autoclass:: CardTypeConverter
   :members:
   :undoc-members:   
   :inherited-members:
