:mod:`UiControllerMain`
===============================

.. automodule:: mnemosyne.libmnemosyne.ui_controller_main
   
.. autoclass:: UiControllerMain
   :members:
   :undoc-members:   
   :inherited-members:
