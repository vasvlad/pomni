:mod:`Filter`
===============================

.. automodule:: mnemosyne.libmnemosyne.filter
   
.. autoclass:: Filter
   :members:
   :undoc-members:   
   :inherited-members:
