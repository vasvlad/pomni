:mod:`ComponentManager`
===============================

.. automodule:: mnemosyne.libmnemosyne.component_manager
   
.. autoclass:: ComponentManager
   :members:
   :undoc-members:   
   :inherited-members:
