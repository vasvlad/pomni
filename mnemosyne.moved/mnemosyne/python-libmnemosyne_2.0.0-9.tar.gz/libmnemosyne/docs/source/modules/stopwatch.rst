:mod:`Stopwatch`
===============================

.. automodule:: mnemosyne.libmnemosyne.stopwatch
   
.. autoclass:: Stopwatch
   :members:
   :undoc-members:   
   :inherited-members:
