:mod:`Plugin`
===============================

.. automodule:: mnemosyne.libmnemosyne.plugin
   
.. autoclass:: Plugin
   :members:
   :undoc-members:   
   :inherited-members:
