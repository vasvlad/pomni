:mod:`FunctionHook`
===============================

.. automodule:: mnemosyne.libmnemosyne.function_hook
   
.. autoclass:: FunctionHook
   :members:
   :undoc-members:   
   :inherited-members:
