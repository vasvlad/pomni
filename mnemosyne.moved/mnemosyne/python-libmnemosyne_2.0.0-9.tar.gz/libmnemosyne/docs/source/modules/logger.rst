:mod:`Logger`
===============================

.. automodule:: mnemosyne.libmnemosyne.logger
   
.. autoclass:: Logger
   :members:
   :undoc-members:   
   :inherited-members:
