:mod:`Card`
===============================

.. automodule:: mnemosyne.libmnemosyne.card
   
.. autoclass:: Card
   :members:
   :undoc-members:   
   :inherited-members:
