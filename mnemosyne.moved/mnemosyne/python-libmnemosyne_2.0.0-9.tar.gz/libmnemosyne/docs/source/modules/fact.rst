:mod:`Fact`
===========

.. automodule:: mnemosyne.libmnemosyne.fact

.. autoclass:: Fact
   :members:
   :undoc-members:   
   :inherited-members:
