:mod:`CardType`
===============================

.. automodule:: mnemosyne.libmnemosyne.card_type
   
.. autoclass:: CardType
   :members:
   :undoc-members:   
   :inherited-members:
