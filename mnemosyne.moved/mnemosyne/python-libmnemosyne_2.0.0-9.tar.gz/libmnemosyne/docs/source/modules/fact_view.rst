:mod:`FactView`
======================

.. automodule:: mnemosyne.libmnemosyne.fact_view

.. autoclass:: FactView
   :members:
   :undoc-members:   
   :inherited-members:
