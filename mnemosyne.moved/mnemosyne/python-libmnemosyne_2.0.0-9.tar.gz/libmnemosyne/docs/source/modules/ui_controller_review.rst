:mod:`UiControllerReview`
===============================

.. automodule:: mnemosyne.libmnemosyne.ui_controller_review
   
.. autoclass:: UiControllerReview
   :members:
   :undoc-members:   
   :inherited-members:
