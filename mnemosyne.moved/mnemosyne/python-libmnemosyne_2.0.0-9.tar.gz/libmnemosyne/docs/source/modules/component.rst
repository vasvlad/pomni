:mod:`Component`
======================

.. automodule:: mnemosyne.libmnemosyne.component

.. autoclass:: Component
   :members:
   :undoc-members:   
   :inherited-members:
