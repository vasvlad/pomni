:mod:`ReviewWidget`
===============================

.. automodule:: mnemosyne.libmnemosyne.review_widget
   
.. autoclass:: ReviewWidget
   :members:
   :undoc-members:   
   :inherited-members:
