:mod:`Scheduler`
===============================

.. automodule:: mnemosyne.libmnemosyne.scheduler
   
.. autoclass:: Scheduler
   :members:
   :undoc-members:   
   :inherited-members:
