"""Proxy for the GTK pango module."""

from real_pango import *
